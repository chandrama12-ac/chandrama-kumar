# iris_app.py

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier
import joblib
import os

st.set_page_config(page_title="Iris ML Predictor", layout="centered")
st.title("🌼 Iris Flower Species Predictor")
st.write("Enter flower measurements to predict the species using a trained ML model.")

# -----------------------
# Step 1: Load or Train Model
# -----------------------
@st.cache_resource
def load_or_train_model():
    model_path = "model.pkl"
    if os.path.exists(model_path):
        model = joblib.load(model_path)
    else:
        iris = load_iris()
        X = pd.DataFrame(iris.data, columns=iris.feature_names)
        y = iris.target
        model = RandomForestClassifier()
        model.fit(X, y)
        joblib.dump(model, model_path)
    return model

model = load_or_train_model()

# -----------------------
# Step 2: Sidebar for Input
# -----------------------
st.sidebar.header("🔧 Input Parameters")

def user_input():
    sepal_length = st.sidebar.slider('Sepal Length (cm)', 4.3, 7.9, 5.1)
    sepal_width = st.sidebar.slider('Sepal Width (cm)', 2.0, 4.4, 3.5)
    petal_length = st.sidebar.slider('Petal Length (cm)', 1.0, 6.9, 1.4)
    petal_width = st.sidebar.slider('Petal Width (cm)', 0.1, 2.5, 0.2)
    data = {
        'sepal length (cm)': sepal_length,
        'sepal width (cm)': sepal_width,
        'petal length (cm)': petal_length,
        'petal width (cm)': petal_width
    }
    return pd.DataFrame(data, index=[0])

input_df = user_input()
st.subheader(" Your Input:")
st.write(input_df)

# -----------------------
# Step 3: Prediction
# -----------------------
prediction = model.predict(input_df)
prediction_proba = model.predict_proba(input_df)
classes = ['Setosa', 'Versicolor', 'Virginica']

st.subheader("🔮 Prediction")
st.write(f"**Predicted Class:** {classes[prediction[0]]}")

st.subheader(" Prediction Probabilities")
st.write(pd.DataFrame(prediction_proba, columns=classes))

# -----------------------
# Step 4: Visualization
# -----------------------
st.subheader(" Feature Importance")
fig, ax = plt.subplots()
importances = model.feature_importances_
sns.barplot(x=importances, y=input_df.columns, ax=ax)
ax.set_title("Feature Importances")
st.pyplot(fig)

st.markdown("---")
st.caption("Built with ❤️ using Streamlit & scikit-learn")
