# --------------------------------------
# 🏠 House Price Prediction (No CSV!)
# --------------------------------------

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score
import seaborn as sns
import matplotlib.pyplot as plt

# ✅ 1. Sample Dataset (Extended to 20 rows)
data = {
    'LotArea': [8450, 9600, 11250, 9550, 14260, 14115, 10084, 10382, 6120, 7420,
                11200, 12350, 9850, 7400, 6900, 8400, 11400, 7600, 9700, 8200],
    'OverallQual': [7, 6, 7, 7, 8, 5, 5, 5, 6, 5,
                    8, 7, 6, 5, 5, 6, 8, 5, 7, 6],
    'YearBuilt': [2003, 1976, 2001, 1915, 2000, 1993, 2004, 1973, 1931, 1939,
                  2005, 2006, 1999, 1961, 1950, 1975, 2007, 1965, 1998, 1991],
    'YrSold': [2008, 2007, 2008, 2006, 2008, 2007, 2008, 2007, 2008, 2007,
               2009, 2008, 2009, 2007, 2008, 2009, 2009, 2008, 2009, 2009],
    'Neighborhood': ['CollgCr', 'Veenker', 'CollgCr', 'Crawfor', 'NoRidge',
                     'Mitchel', 'Somerst', 'NWAmes', 'OldTown', 'BrkSide',
                     'CollgCr', 'NoRidge', 'Somerst', 'NWAmes', 'OldTown',
                     'Mitchel', 'NoRidge', 'Crawfor', 'Somerst', 'BrkSide'],
    'SalePrice': [208500, 181500, 223500, 140000, 250000,
                  143000, 307000, 200000, 129900, 118000,
                  315000, 365000, 250000, 195000, 140000,
                  160000, 400000, 225000, 270000, 135000]
}

df = pd.DataFrame(data)
print("✅ Sample data created!")
print(df.head())

# ✅ 2. Feature Engineering
df['HouseAge'] = df['YrSold'] - df['YearBuilt']
df['TotalSF'] = df['LotArea'] + df['HouseAge']

# ✅ 3. One-Hot Encoding for Neighborhood
df = pd.get_dummies(df, columns=['Neighborhood'], drop_first=True)

# ✅ 4. Separate features and target
X = df.drop('SalePrice', axis=1)
y = df['SalePrice']

# ✅ 5. Feature Scaling
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ✅ 6. Train/Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42)

# ✅ 7. Train Model
model = LinearRegression()
model.fit(X_train, y_train)

# ✅ 8. Evaluate Model
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"\n📉 MSE: {mse:.2f}")
print(f"📈 R² Score: {r2:.2f}")

# ✅ 9. Feature Importance
coefs = pd.Series(model.coef_, index=X.columns)
top_features = coefs.abs().sort_values(ascending=False).head(10)

# ✅ 10. Visualizations
plt.figure(figsize=(10, 6))
sns.barplot(x=top_features.values, y=top_features.index, palette="mako")
plt.title("Top 10 Feature Importances")
plt.xlabel("Coefficient Magnitude")
plt.tight_layout()
plt.show()

# ✅ 11. Distribution of Sale Price
plt.figure(figsize=(8, 5))
sns.histplot(df['SalePrice'], bins=10, kde=True, color='skyblue')
plt.title("Distribution of House Sale Prices")
plt.xlabel("Sale Price")
plt.ylabel("Frequency")
plt.tight_layout()
plt.show()

# ✅ 12. Heatmap of Correlations
plt.figure(figsize=(12, 6))
corr_matrix = df.corr(numeric_only=True)
sns.heatmap(corr_matrix, annot=True, cmap="coolwarm", fmt=".2f", linewidths=0.5)
plt.title("Correlation Heatmap of Features")
plt.tight_layout()
plt.show()
