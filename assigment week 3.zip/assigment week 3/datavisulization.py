import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Mock internship data for Celebal Technologies
data = {
    'Intern': ['Amit', 'Priya', 'Rahul', 'Sneha', 'Karan', 'Neha', 'Vivek', 'Anita', 'Rohan', 'Anjali'],
    'Department': ['Data Science', 'Data Science', 'Web Dev', 'Web Dev', 'AI/ML', 'AI/ML', 'DevOps', 'DevOps', 'Testing', 'Testing'],
    'Duration (months)': [3, 4, 3, 4, 6, 3, 3, 4, 2, 3],
    'Project Score (%)': [85, 90, 78, 82, 92, 88, 75, 80, 70, 89],
    'Stipend (₹/month)': [10000, 12000, 9000, 11000, 15000, 13000, 8000, 10000, 7000, 12500]
}

df = pd.DataFrame(data)
print("Internship Data:\n", df)

#  Plot 1: Count of Interns by Department
plt.figure(figsize=(8, 5))
sns.countplot(x='Department', data=df, palette='Set2')
plt.title('Number of Interns per Department')
plt.xlabel('Department')
plt.ylabel('Count of Interns')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

#  Plot 2: Boxplot of Project Scores by Department
plt.figure(figsize=(8, 5))
sns.boxplot(x='Department', y='Project Score (%)', data=df, palette='Set3')
plt.title('Distribution of Project Scores by Department')
plt.xlabel('Department')
plt.ylabel('Project Score (%)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

#  Plot 3: Scatterplot Duration vs Project Score, sized by Stipend
plt.figure(figsize=(8, 6))
sns.scatterplot(
    data=df,
    x='Duration (months)',
    y='Project Score (%)',
    size='Stipend (₹/month)',
    hue='Department',
    palette='tab10',
    sizes=(100, 400),
    alpha=0.8
)
plt.title('Duration vs Project Score (size ~ Stipend)')
plt.xlabel('Duration (months)')
plt.ylabel('Project Score (%)')
plt.legend(bbox_to_anchor=(1.05, 1), loc=2)
plt.tight_layout()
plt.show()

#  Plot 4: Bar plot of Average Stipend by Department
plt.figure(figsize=(8, 5))
dept_stipend = df.groupby('Department')['Stipend (₹/month)'].mean().reset_index()
sns.barplot(x='Department', y='Stipend (₹/month)', data=dept_stipend, palette='Blues_d')
plt.title('Average Stipend per Department')
plt.xlabel('Department')
plt.ylabel('Avg Stipend (₹/month)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
