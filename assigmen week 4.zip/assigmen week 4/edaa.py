# eda.py

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# For better plots
sns.set(style="whitegrid")
plt.rcParams["figure.figsize"] = (10, 6)

# -------------------------------
# Step 1: Generate a Complex Dataset
# -------------------------------
np.random.seed(42)
n_samples = 1000

df = pd.DataFrame({
    'Age': np.random.normal(35, 10, n_samples).astype(int),
    'Salary': np.random.normal(70000, 15000, n_samples),
    'Department': np.random.choice(['HR', 'Tech', 'Finance', 'Marketing'], n_samples),
    'Experience': np.random.randint(1, 30, n_samples),
    'Satisfaction': np.random.uniform(1, 5, n_samples),
    'Left_Company': np.random.choice([0, 1], n_samples, p=[0.8, 0.2])
})

# Inject missing values
df.loc[np.random.choice(df.index, 50), 'Salary'] = np.nan
df.loc[np.random.choice(df.index, 30), 'Satisfaction'] = np.nan

# Inject outliers
df.loc[np.random.choice(df.index, 5), 'Salary'] *= 4

# -------------------------------
# Step 2: Summary Statistics
# -------------------------------
print("\n🟨 BASIC INFO:\n")
print(df.info())

print("\n🟩 DESCRIPTIVE STATISTICS:\n")
print(df.describe(include='all'))

# -------------------------------
# Step 3: Missing Values
# -------------------------------
print("\n🟥 MISSING VALUES:\n")
print(df.isnull().sum())

# -------------------------------
# Step 4: Visualizations
# -------------------------------

# Histograms
df.hist(bins=30, figsize=(14, 10), edgecolor='black')
plt.suptitle("Histograms of Numeric Features", fontsize=16)
plt.tight_layout()
plt.show()

# Boxplots for outliers
for col in ['Age', 'Salary', 'Experience', 'Satisfaction']:
    sns.boxplot(x=df[col])
    plt.title(f'Boxplot of {col}')
    plt.show()

# Heatmap for correlation
plt.figure(figsize=(10, 6))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Heatmap')
plt.show()

# Pairplot
sns.pairplot(df.dropna(), hue="Department", diag_kind='hist')
plt.suptitle("Pairwise Relationships", fontsize=16)
plt.show()

# Countplot for categorical target
sns.countplot(x='Left_Company', data=df)
plt.title('Employee Attrition Count')
plt.show()

# -------------------------------
# Step 5: Relationships
# -------------------------------
sns.boxplot(x='Department', y='Salary', data=df)
plt.title("Salary Distribution by Department")
plt.xticks(rotation=45)
plt.show()

sns.barplot(x='Department', y='Satisfaction', data=df)
plt.title("Average Satisfaction by Department")
plt.show()

print("\n✅ EDA Completed Successfully.")
